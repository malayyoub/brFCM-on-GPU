/* 

   brfcm - BitReduction FCM. Reduced precision through quantization
   (e.g. bit reduction) and aggregation.

   $Id: brfcm.c,v 1.2 2002/07/12 20:48:48 eschrich Exp $
   Steven Eschrich
   
   Copyright (C) 2002 University of South Florida

   This program is free software; you can redistribute it and/or modify it 
   under the terms of the GNU General Public License as published by the 
   Free Software Foundation; either version 2 of the License, or (at 
   your option) any later version.
   
   This program is distributed in the hope that it will be useful, but 
   WITHOUT ANY WARRANTY; without even the implied warranty of 
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
   General Public License for more details.
   
   You should have received a copy of the GNU General Public License along 
   with this program; if not, write to the Free Software Foundation, Inc., 
   59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include <math.h>
#include <sys/types.h>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h>
#include <sys/resource.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>
#include "utils.h"
//#include <vector>




/* Macros defined here. */
/* The membership matrix (U) is indexed as U(cluster,example). However,
   for efficiency when calculating one example at a time, the arrays
   are created as U[example][cluster] so that all operations for a 
   particular example (e.g. the membership update) occur in contiguous 
   memory locations. 

   A macro is used to hide the differences in the code
*/
#define U(cluster,example) U[example][cluster]



/*==============================================================
 * 
 * Global variables 
 * 
 * There are many global variables in this file. This is mainly
 * so that individual parameters, counters can be accessed by
 * external functions (i.e. the calling function).
 *==============================================================*/
/* 
   Several variables are used to calculate the size of the hash
   table. 

   The expected reduction in the dataset is the number of examples
   after compression (n*(1-expected_reduction)).

   The expected_number_of_collisions determines the size of the hash
   table.
*/
float expected_reduction=0.02;
int    expected_number_of_collisions=3;


/* 
   There are a variety of variables needed for a typical FCM clustering
   algorithm. 
*/

/* (0.225) Epsilon is the stopping condition; a change less than epsilon
   in sum squared difference in the U matrix stops the algorithm.
*/
float epsilon=0.225;
/* (2.0) Fuzziness factor. Determines how fuzzy the clustering is */
float m=2.0;

/* (2) The number of clusters (often seen/called K in kmeans clustering) */
int    C=2;

/* Data structures to hold clustering information */
/* Cluster centroids */
float **V;
/* Membership matrix */
float **U;

/* Dataset variables */
/* The dataset (examples) */
float **X;
/* Counter for num iterations */
int    number_of_iterations;
/* Number of examples */
int    N=1;
/* Number of features */
int    S=1;



/* BRFCM specific variables */
/* Number of bits to reduce */
int    R=0;
/* Number of reduced examples */
int    N0=0;
/* Collision statistic for hashing */
int    max_number_of_collisions;
/* Flag for turning hashing on/off */
Boolean use_hashing=True;

/*
  BRFCM-specific data struct, Bins. This is the data structure to
  hold each quantized value and the associated members.
*/
typedef struct BinStruct {
  float    *X;           /* Full-precision (average) example */
  float    *rX;          /* Reduced-precision (quantized) example */
  int       *members;     /* Array of indices pointing to quant. members */
  long int  w;            /* Number of members (weight) */
} Bins;
Bins        *bins;
float **mat;
long int *Ws;
/*
  A couple of miscellaneous variables 
*/
int      *max_value;               /* Stores max feature value per feature */
long     seed;                     /* Random seed */
struct rusage compressing_usage;   /* Timing for compressing stage */


/*==============================================================
 * 
 *  Function Prototypes
 *
 *==============================================================*/
/* The main clustering functions */
int    brfcm();
int    update_centroids();
float update_umatrix();

/* Utilities */
int    init();
int    is_example_centroid();
float distance();
int    distribute_membership();

/* brfcm-specific functions (quantization/aggregation) */
int reduce();
int reduce_vector();
int simple_find();
int hash_find();
int create_new_bin();

/* Hash Utilities */
int hash_init();
int hash_update();
int h();


int output_centroids();
int output_umatrix();
int output_members();





/*==============================================================
 * 
 *  External Function Prototypes
 *
 *==============================================================*/
int load_test_data();
int load_atr_data();
int load_mri_data();






/*==============================================================
 * 
 *  Main Function
 *
 *==============================================================*/
/* For testing purposes, we hard-code the desired number of clusters */
#define ATR_NUMBER_OF_CLUSTERS 5
#define MRI_NUMBER_OF_CLUSTERS 10
#define TEST_NUMBER_OF_CLUSTERS 2
#define TEST  1
#define ATR   2
#define MRI   3
#define Squared 1

/* Global variables */
int     dataset_type=MRI;
int     write_centroids=0;
int     write_umatrix=0;
int     write_members=0;

/* Variables that must be defined for called functions */
int  vals[][3]={{256,256,256},{0,0,0},{256,256,256},{4096,4096,4096}};


/* Function prototypes */
float *timing_of();  /* Calculate time in seconds */
float update_time =0;



int main(int argc, char **argv)
{

  struct rusage start_usage, end_usage;
  int ch;
  float *perf_times;
  char   *filename;

  epsilon=0.225;
  m=2.0;
  seed=2000;
  max_value=vals[dataset_type];
  use_hashing=True;

  while ( (ch=getopt(argc, argv,"hr:u:w:d:s:")) != EOF ) {
    switch (ch) {
    case 'h':
      fprintf(stderr,"Usage\n" \
	      "-r # number of bits to reduce\n"\
	      "-u Disable use of hashing for bit reduction\n"\
	      "-d [a|t|m|s] Use dataset atr, mri, test, seawifs\n"\
	      "-w write cluster centers and memberships out\n"\
	      "-s seed  Use seed as the random seed\n");
      exit(1);
    case 'r': /* number of bits to reduce */
      R=atoi(optarg);
      break;
    case 'u': /* Disable use of hashing. Ultra fast, some pnemonic */
      use_hashing=False;
      break;
    case 'w':
      if ( !strcmp(optarg,"umatrix") ) write_umatrix=1;
      if ( !strcmp(optarg,"centroids") ) write_centroids=1;
      if ( !strcmp(optarg,"members") ) write_members=1;
      if ( !strcmp(optarg,"all")) 
	write_umatrix=write_centroids=write_members=1;
      break;
    case 'd':
      if ( *optarg == 'a' ) dataset_type=ATR;
      if ( *optarg == 'm' ) dataset_type=MRI;
      if ( *optarg == 't' ) dataset_type=TEST;
      max_value=vals[dataset_type];
      break;
    case 's':
      seed=atol(optarg);
      break;
    default:
fprintf(stdout,"default\n");
    }
  }
  /* Print out main parameters for this run */
  fprintf(stdout,"FCM Parameters\n clusterMethod=brfcm\n");
  filename=argv[optind];
  fprintf(stdout," file=%s\n",filename);
  fprintf(stdout," bit reduction=%d\n use Hashing=%s\n\n",R,use_hashing?"yes":"no");


  /* Load the dataset, using one of a particular group of datasets. */
  switch (dataset_type) {
  case TEST:
    load_test_data(&X, &S, &N);
    C=TEST_NUMBER_OF_CLUSTERS;
    break;
  case ATR:
    load_atr_data(argv[optind],&X, &S, &N);
    C=ATR_NUMBER_OF_CLUSTERS;
    break;
  case MRI:
    load_mri_data(argv[optind], &X, &S, &N);
    C=MRI_NUMBER_OF_CLUSTERS;
    break;
  }


  fprintf(stdout, "Beginning to cluster...\n");


  /* Time the brfcm algorithm */
  getrusage(RUSAGE_SELF, &start_usage);
  brfcm();
  getrusage(RUSAGE_SELF, &end_usage);


  /* Output whatever clustering results we need */
  if ( write_centroids ) output_centroids(filename);
  if ( write_umatrix   ) output_umatrix(filename);
  if ( write_members   ) output_members(filename);

   
  /* Output timing numbers */
  perf_times=timing_of(start_usage, compressing_usage);
  printf("Compressing Timing: %f user, %f system, %f total.\n", 
				perf_times[0], perf_times[1], perf_times[0] +
				perf_times[1]);
  perf_times=timing_of(compressing_usage, end_usage);
  printf("Clustering Timing: %f user, %f system, %f total.\n", 
				perf_times[0], perf_times[1], perf_times[0] +
				perf_times[1]);
  perf_times=timing_of(start_usage, end_usage);
  printf("Total Timing: %f user, %f system, %f total.\n", 
				perf_times[0], perf_times[1], perf_times[0] +
				perf_times[1]);

   printf("Clustering required %d iterations.\n", number_of_iterations);
  printf("Dataset size %d reduced to %d, %f%% reduction.\n", N, N0,
			100.0*(1.0-(N0/(float)N)));
  printf("Max. hash table collisions: %d\n", max_number_of_collisions);

   return 0;
}




/************************************************************
 * 
 * Main functions for the file:
 *  generally call only brfcm()
 *
 ************************************************************/
int brfcm()
{
  float sqrerror = 2 * epsilon;
  
  /* initialize counters */
  number_of_iterations=0;

  /* Reduce dataset before continuing. This routine will set bins
     and return the number of reduced vectors. */
  N0=reduce();

//for (int i=0;i < array.size(); i++)
 //printf("vector: %f\n", array[i]);
  /* Dynamically allocate storage */
  init();
  
  /* Run the updates iteratively */
  while (sqrerror > epsilon ) {
    number_of_iterations++;
    update_centroids();
    sqrerror=update_umatrix();

  }
  
  /* We go ahead and update the centroids - presumably this will not 
     change much, since the overall square error in U is small */
  update_centroids();
  
  
  /* Special case for brfcm - distribute reduced vector membership */
 distribute_membership();
  
  
  return 0;
}



/* 
   update_centroids()
    Given a membership matrix U, recalculate the cluster centroids as the
    "weighted" mean of each contributing example from the dataset. Each
    example contributes by an amount proportional to the membership value.
*/
int update_centroids()
{
  int i,k,x;
  float numerator[S], denominator;
  float U_ikm;

  /* For each cluster */
  for (i=0; i < C; i++)  {
   
    /* Zero out numerator and denominator options */
    denominator=0;
    for (x=0; x < S; x++) 
      numerator[x]=0;

    /* Calculate numerator and denominator together */
    for (k=0; k < N0; k++) {
      //U_ikm=bins[k].w * pow(U(i,k),m);
      #if Squared
       U_ikm=Ws[k] * U(i,k) * U(i,k);
      #else
       U_ikm=Ws[k] * powf(U(i,k),m);
      #endif
      denominator += U_ikm;
      for (x=0; x < S; x++) 
	//numerator[x] += U_ikm * bins[k].X[x];
        numerator[x] += U_ikm * mat[k][x];
    }

    
    /* Calculate V */
    for (x=0; x < S; x++) 
      V[i][x]= numerator[x] / denominator;

    
  }  /* endfor: C clusters */

  return 0;
}

float update_umatrix()
{
  int i,j,k;
  int example_is_centroid;
  //float summation, D_k[C];
  float summation, D_ki, D_kj;
  //float summation;
  float square_difference=0;
  float newU;
 // float *D_k=(float *)malloc(C* sizeof(float)) ;

  /* For each example in the dataset */
  for ( k=0; k < N0; k++) {
    
    /* Special case: If Example is equal to a Cluster Centroid,
       then U=1.0 for that cluster and 0 for all others */
    if ( (example_is_centroid=is_example_centroid(k)) != -1 ) {
      //fprintf(stderr,"Example is centroid\n");
      for (i=0; i < C; i++) {
	if ( i == example_is_centroid ) {
	  //square_difference += (U(i,k) -1.0) * (U(i,k)-1.0) * bins[k].w;
square_difference += (U(i,k) -1.0) * (U(i,k)-1.0) * Ws[k];
	  U(i,k)=1.0;
	} else {
	  //square_difference += U(i,k) * U(i,k) * bins[k].w;
square_difference += U(i,k) * U(i,k) * Ws[k];
	  U(i,k)=0.0;
	}
      }
      continue;
    }

    /* Cache the distance between this vector and all centroids. */
    //for (i=0; i < C; i++) 
     // D_k[i]=distance(bins[k].X, V[i]);
//D_k[i]=distance(mat[k], V[i]);
   
    /* For each class */
    for (i=0; i < C; i++) {
      summation=0;

      /* Calculate summation */
      for (j=0; j < C; j++) {
	if ( i == j ) 
	  summation+=1.0;
	else
          {

            D_ki=distance(mat[k], V[i]);
	    D_kj=distance(mat[k], V[j]);
            #if Squared
            summation += (D_ki / D_kj) * (D_ki / D_kj);
            #else
            summation += powf( D_ki / D_kj , (2.0/ (m-1)));
            #endif
	  //summation += pow( D_k[i] / D_k[j] , (2.0/ (m-1)));
           }
      }

      /* Weight is 1/sum */
      newU=1.0/(float)summation;
      
      /* Add to the squareDifference */
      //square_difference += (U(i,k) - newU) * (U(i,k) - newU) * bins[k].w ;
square_difference += (U(i,k) - newU) * (U(i,k) - newU) * Ws[k] ;
      //printf("square_difference%f\n", square_difference);
      U(i,k)=newU;
    }

  } /* endfor N0 */
  
 //free(D_k);
//printf("square_difference%f\n", square_difference);
  return square_difference;

}



/*=================================================================
  General Utilities

  init()                  - allocate space for data structures
  is_example_centroid()   - Compare an example to cluster centroids
  is_equal()              - Are two vectors equal (in all dimensions)
  distance()              - Distance metric between two vectors
  distribute_membership() - Distribute reduced-vector memberships to
                             all members of the bin 
			     (replace U with a full U).
  =================================================================*/

/* Allocate storage for U and V dynamically. */
int init()
{
  int i,j;

  /* Allocate necessary storage */
  V=(float **)CALLOC(C,sizeof(float *));
  for (i=0; i < C; i++) 
    V[i]=(float *)CALLOC(S,sizeof(float));

  U=(float **)CALLOC(N0, sizeof(float *));
  for (i=0; i < N0; i++)
    U[i]=(float *)CALLOC(C,sizeof(float));

  /* Place random values in V, then update U matrix based on it */
  srand48(seed);
  for (i=0; i < C; i++) {
    for (j=0; j < S; j++) {
      V[i][j]=drand48() * max_value[j];
    }
  }
  
  /* Once values are populated in V, update U matrix to sane values */
  update_umatrix();

  return 0;
}


/* If X[k] == V[i] for some i, then return that i. Otherwise, return -1 */
int is_example_centroid(int k)
{
  int  i,x;

  for (i=0; i < C; i++) {
    for (x=0; x < S; x++) {
//printf("k=%d, x=%d, S=%d, Bins:bins[k].X[x]: %f\n", k, x, S, bins[k].X[x]);
      //if ( bins[k].X[x] != V[i][x] ) break;
if ( mat[k][x] != V[i][x] ) break;
    }
    if ( x == S )  /* X==V */
      return i;
  }

  return -1;
}            

int is_equal(float *v1, float *v2)
{
   int i;

   for (i=0; i < S; i++) 
      if ( v1[i] != v2[i] ) return 0;
   return 1;
}

float distance(float *v1, float *v2)
{
   int x;
   float sum=0;

   for (x=0; x < S; x++) 
      sum += (v1[x]-v2[x]) * (v1[x]-v2[x]);

   return sqrt(sum);
}

/* distribute U matrix values to the entire dataset. Creates
   a full U matrix, copies things over and destroys the old
   one. */
int distribute_membership()
{
  float **newU;
  int i,j,k;

  newU=(float **)CALLOC(N,sizeof(float *));
  for (i=0; i < N; i++)
    newU[i]=(float *)CALLOC(C,sizeof(float));


   /* Go through each bin, and distribute U values */
   for (i=0; i < N0; i++) {
      //for (j=0; j<bins[i].w; j++) {
for (j=0; j<Ws[i]; j++) {
	 for (k=0; k < C; k++) {
	    newU[bins[i].members[j]][k]=U[i][k];
         }
      }
      free(U[i]);
   }
   free(U);
   U=newU;

   return 0;
}


/*=============================================================
  Public output utilities

  output_centroids(char *filestem)
  output_umatrix(char *filestem)
  output_members(char *filestem)
  =============================================================*/

int output_centroids(char *filestem)
{
  FILE *fp;
  char buf[1024];
  int i,j;

  sprintf(buf,"%s.centroids", filestem);
  fp=FOPEN(buf,"w");

  for (i=0;i < C ;i++) {
    for (j=0; j < S; j++)
       fprintf(fp, "%f\t",V[i][j]);
    fprintf(fp,"\n");
  }
  fclose(fp);

  return 0;
}

int output_umatrix(char *filestem)
{
  FILE *fp;
  char buf[1024];
  int i,j;

  sprintf(buf, "%s.umatrix", filestem);
  fp=FOPEN(buf,"w");

  for (i=0; i < N; i++) {
    for (j=0; j < C; j++)
      fprintf(fp,"%f\t", U[i][j]);
    fprintf(fp,"\n");
  }
  fclose(fp);

  return 0;
}


int output_members(char *filestem)
{
  FILE *fp;
  char buf[1024];
  int i,j,max;
  
  sprintf(buf,"%s.members",filestem);
  fp=FOPEN(buf,"w");
  for (i=0; i < N; i++ ) {
    for (max=j=0; j < C; j++) {
      if ( U[i][j] > U[i][max] ) max=j;
    }
    fprintf(fp,"%d\n",max);
  }
  fclose(fp);
  return 0;

}


/*================================================================
  Reduction utilities.
  Functions used for reduction of data elements (via quantization
  and aggregation).

  reduce()           - Reduce all vectors
  reduce_vector()    - Perform the quantization (bit shifting)
  create_new_bin()   - Not found, add a new bin

  ================================================================*/

/* reduce() - Reduce the dataset to n0 vectors, and return n0 */
int reduce()
{
  int i,x;
  float alpha;
  int target;
  float *rv;
//float **mat;
  N0=0;
  max_number_of_collisions=0;

  /* Allocate enough storage for 25% of n, assuming a 3/4 reduction */
  bins=(Bins *)CALLOC((int)(N*(1.0-expected_reduction)), sizeof(Bins));
  rv=(float *)CALLOC(S,sizeof(float));

    mat=(float **)CALLOC(N*(1.0-expected_reduction),sizeof(float *));
  for (i=0; i < N*(1.0-expected_reduction); i++)
    mat[i]=(float *)CALLOC(S,sizeof(float));
      
Ws = (long int *)CALLOC(N*(1.0-expected_reduction),sizeof(long int));

  /* If hashing is used, intialize it */
  if ( use_hashing ) hash_init();

  /* Go through each example and add it to the appropriate bin */
  for (i=0; i < N; i++) {
    /* Reduce vector into rv */
    reduce_vector( rv, X[i], R);

    /* Find it (either via hashing or directly) */
    if ( use_hashing )
      target=hash_find(rv);
    else
      target=simple_find(rv, N0);
//printf("target=%d\n", target);

    /* If bin not found, create a new one */
    if ( target == -1 ) {
      create_new_bin(rv,N0);
      if ( use_hashing ) hash_update(rv, N0);
      target=N0;
      N0++;
    }


    /* Add to current bin */
    bins[target].members=(int *)REALLOC(bins[target].members,
                                             (bins[target].w+1) * sizeof(int));

    bins[target].members[bins[target].w]=i;
    bins[target].w++;
    Ws[target]= bins[target].w;
//printf("Ws[target]=%d\n", Ws[target]);

    /* Update running average */
    alpha=1.0/(bins[target].w);
    for (x=0; x < S; x++) {
      bins[target].X[x]=(1.0-alpha) * bins[target].X[x] +
	alpha * X[i][x];
//printf("Bins:bins[target].X[x]: %f\n", bins[target].X[x]);
mat[target][x] = bins[target].X[x];
//printf("Bins:mat[target][x]: %f\n", mat[target][x]);
    }
    
  }
  /* Get timing information */
  getrusage(RUSAGE_SELF,&compressing_usage);

//printf("N0 value inside reduce function: %d\n", N0);

  return N0;
}


/* Reduce a vector (quantize) by shifting k bits. */
int reduce_vector(float *rv, float *v, int k)
{
  int i;

  for (i=0; i < S; i++)
    rv[i]=((int)v[i]) >> k;

  return 0;
}

/* No bin found for vector, create a new one */
int create_new_bin(float *rv, int n0)
{
  int i;

  if ( n0 >= N*(1.0-expected_reduction) ) 
    die("Expected reduction overflow %d",n0);

  bins[n0].rX=(float *)CALLOC(S,sizeof(float));
  bins[n0].X=(float *)CALLOC(S,sizeof(float));
  bins[n0].members=NULL;
  bins[n0].w=0;
  for (i=0; i < S; i++) {
    bins[n0].rX[i]=rv[i];
    bins[n0].X[i]=0;
  }
  return n0;
}                


/*====================================================================
  Finding routines. The most intensive task in reduction and aggregation
  is attempting to match identical feature vectors. We can do a 
  simple linear search through the vectors, or use hashing.

  simple_find()  - Find appropriate location through a linear search
  
  ====================================================================*/
int simple_find(float *rv, int n0)
{
//printf("hello find\n");

   int i;
   for (i=0; i < n0; i++) 
      if ( is_equal(bins[i].rX, rv) ) return i;
   return -1;
}


/*=============================
  Hashing maintenance routines 
  =============================*/
struct HashElementStruct {
   int v;
   struct HashElementStruct *next;
};
typedef struct HashElementStruct HashElement;

static HashElement **hash_table;
static int *a;
static int expectedN;
static int mod_value;


/* The hash is a chained hash, therefore find the bucket and search the
   chain. */
int hash_find(float *rv)
{
//printf("hello hash\n");
   HashElement *p;

   p=hash_table[h(rv)];

   for (; p != NULL; p=p->next) 
      if ( is_equal(bins[p->v].rX, rv) ) return p->v;
   

   return -1;
}


/* The hashing function. Returns an index into hash table */
int h(float *v)
{
   int i;
   int sum=0;

   for (i=0; i < S; i++) 
      sum += a[i] * v[i];
   sum = sum % mod_value;

   return abs(sum);
}


/* Initialize the hash data structure. Based on the expected number
   of entries, the h() function and the hash table size is tweaked.
*/
int hash_init()
{
   int i;

   expectedN= N * (1.0 - expected_reduction);

   /* Allocate storage space */
   hash_table=(HashElement **)CALLOC(expectedN, sizeof(HashElement *));
   a=(int *)CALLOC(S,sizeof(int));


   mod_value = expectedN/expected_number_of_collisions;

   /* We use rand48() elsewhere, so they shouldn't? conflict. */
   srand(time(NULL));
   /* Initialize a table to random values */
   for (i=0; i < S; i++) 
      a[i]=rand() % mod_value;

   return 0;   
}


/* hash_update - The value of v was not in the hash table, insert it */
int hash_update(float *v, int index)
{
  int hash_value;
  HashElement *p;
  HashElement *new_hash_element;
  int number_of_collisions=0;

  hash_value=h(v);
  p=hash_table[hash_value];

  new_hash_element=(HashElement *)CALLOC(1,sizeof(HashElement));
  new_hash_element->next=0;
  new_hash_element->v=index;

  if ( p == 0 ) {
     hash_table[hash_value]=new_hash_element;
  } else {
     for (;p->next != 0; p=p->next, number_of_collisions++);
     p->next=new_hash_element;
  }
  if ( number_of_collisions > max_number_of_collisions)
     max_number_of_collisions=number_of_collisions;

  return 0;
}





