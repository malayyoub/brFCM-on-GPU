GPU-FCM
=======
